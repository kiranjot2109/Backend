const cloudinary = require('cloudinary').v2;

cloudinary.config({
    cloud_name: 'dkvruj8p6',
    api_key: '647422829569591',
    api_secret: 'Wi3WRIch61_rB5SMoTzg1Qj04JU' // Click 'View API Keys' above to copy your API secret
   
});

  

const uploadImg = async (fileBuffer, publicId) => {
    return new Promise((resolve, reject) => {
        cloudinary.uploader.upload_stream(
            {
                public_id: publicId,
                resource_type: "auto"
            },
            (error, result) => {
                if (error) {
                    reject(error);
                } else {
                    resolve(result.secure_url);
                }
            }
        ).end(fileBuffer);
    });
};

module.exports = {
    uploadImg
};