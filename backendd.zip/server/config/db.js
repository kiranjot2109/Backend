const mongoose = require('mongoose')
let path = "mongodb://127.0.0.1:27017/GYM"
// let path = "mongodb+srv://kaurkiranjot47:HVPtIopa2srFxpMs@kirancls.1sgwu6z.mongodb.net/GYM"
mongoose.connect(path)
    .then(() => {
        console.log('Db Connected')
    })
    .catch((err) => {
        console.log("Db Error", err)
    })


